#pragma once


// CTestPage2 �Ի���
#include "Resource.h"
class CTestPage2 : public CDialog
{
	DECLARE_DYNAMIC(CTestPage2)

public:
	CTestPage2(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CTestPage2();

// �Ի�������
	enum { IDD = IDD_TESTPAGE2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	virtual void OnOK();
	virtual void OnCancel();
public:
	virtual BOOL OnInitDialog();
};
