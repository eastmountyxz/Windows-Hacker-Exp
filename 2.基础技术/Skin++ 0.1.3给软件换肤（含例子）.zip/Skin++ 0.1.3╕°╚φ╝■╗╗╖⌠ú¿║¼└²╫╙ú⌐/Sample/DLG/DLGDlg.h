// DLGDlg.h : header file
//

#if !defined(AFX_DLGDLG_H__A9A8072F_9EDD_490B_B786_D7B50FED7F13__INCLUDED_)
#define AFX_DLGDLG_H__A9A8072F_9EDD_490B_B786_D7B50FED7F13__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include ".\testpage.h"
#include ".\testpage2.h"

/////////////////////////////////////////////////////////////////////////////
// CDLGDlg dialog

class CDLGDlg : public CDialog
{
// Construction
public:
	CDLGDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDLGDlg)
	enum { IDD = IDD_DLG_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDLGDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	CTestPage m_Page1;
	CTestPage2 m_Page2;
	//����ΪHJSkin����

	int ButtonCount;
	int ButtonBitmap;

	CImageList m_StdImageList;
	CImageList m_HotImageList;
	CImageList m_DisableImageList;
	TBBUTTON m_Buttons[20];

	CImageList m_MenuImageList;
	void CreateHSMenu();
	void MFCInit();
	void MFCToolbarInit();
protected:
	// Generated message map functions
	//{{AFX_MSG(CTestHJSkinMangeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTcnSelchangeTab1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedChangeskin();
	afx_msg void OnSkin32773();
	afx_msg void OnWeb();
	afx_msg void OnClose();
	afx_msg void OnBnClickedCheck4();
	afx_msg void OnBnClickedCheckRight();
	afx_msg void OnBnClickedCheckAutosize();
	afx_msg void OnBnClickedRadioSicon();
	afx_msg void OnBnClickedRadioBigicon();
	afx_msg void OnBnClickedCheckText();
	afx_msg void OnBnClickedButtonAdd2();
	afx_msg void OnBnClickedButtonDel();
	afx_msg void OnBnClickedRadio4();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	afx_msg void OnMenuNew();
	afx_msg void OnMenuOpen();
	afx_msg void OnUpdateMenuSave(CCmdUI *pCmdUI);
	afx_msg void OnUpdateMenuPrint(CCmdUI *pCmdUI);
	afx_msg void OnUpdateMenuPaste(CCmdUI *pCmdUI);
	afx_msg void OnMenuSave();
	afx_msg void OnMenuPrint();
	afx_msg void OnMenuCut();
	afx_msg void OnMenuCopy();
	afx_msg void OnMenuPaste();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnBnClickedCheckEx();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButtonSettext();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSkin1();
	afx_msg void OnSkin2();
	afx_msg void OnSkin33();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGDLG_H__A9A8072F_9EDD_490B_B786_D7B50FED7F13__INCLUDED_)
