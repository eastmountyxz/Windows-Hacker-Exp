#pragma once


// CTestPage �Ի���
#include "Resource.h"
class CTestPage : public CDialog
{
	DECLARE_DYNAMIC(CTestPage)

public:
	CTestPage(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CTestPage();

// �Ի�������
	enum { IDD = IDD_TESTPAGE1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	virtual void OnCancel();
	virtual void OnOK();
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonAdd();
	afx_msg void OnBnClickedButtonDel();
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
};
