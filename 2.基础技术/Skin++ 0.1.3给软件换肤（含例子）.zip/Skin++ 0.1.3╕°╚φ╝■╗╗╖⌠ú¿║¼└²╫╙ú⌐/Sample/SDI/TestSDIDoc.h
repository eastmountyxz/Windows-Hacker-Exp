// TestSDIDoc.h : interface of the CTestSDIDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTSDIDOC_H__E95E1633_0796_4B88_ACD3_C1972E10FCCF__INCLUDED_)
#define AFX_TESTSDIDOC_H__E95E1633_0796_4B88_ACD3_C1972E10FCCF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTestSDIDoc : public CDocument
{
protected: // create from serialization only
	CTestSDIDoc();
	DECLARE_DYNCREATE(CTestSDIDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestSDIDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTestSDIDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTestSDIDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTSDIDOC_H__E95E1633_0796_4B88_ACD3_C1972E10FCCF__INCLUDED_)
