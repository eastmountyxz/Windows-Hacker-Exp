// TestSDIEditView.cpp : implementation file
//

#include "stdafx.h"
#include "TestSDI.h"
#include "TestSDIEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSDIEditView

IMPLEMENT_DYNCREATE(CTestSDIEditView, CEditView)

CTestSDIEditView::CTestSDIEditView()
{
}

CTestSDIEditView::~CTestSDIEditView()
{
}


BEGIN_MESSAGE_MAP(CTestSDIEditView, CEditView)
	//{{AFX_MSG_MAP(CTestSDIEditView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSDIEditView drawing

void CTestSDIEditView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CTestSDIEditView diagnostics

#ifdef _DEBUG
void CTestSDIEditView::AssertValid() const
{
	CEditView::AssertValid();
}

void CTestSDIEditView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestSDIEditView message handlers

void CTestSDIEditView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CEdit * pCtrl=&this->GetEditCtrl();
	pCtrl->SetWindowText("����EDIT");
}
