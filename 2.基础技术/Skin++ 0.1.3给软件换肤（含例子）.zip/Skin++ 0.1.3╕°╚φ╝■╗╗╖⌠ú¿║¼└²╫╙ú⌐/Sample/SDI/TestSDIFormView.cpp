// TestSDIFormView.cpp : implementation file
//

#include "stdafx.h"
#include "TestSDI.h"
#include "TestSDIFormView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSDIFormView

IMPLEMENT_DYNCREATE(CTestSDIFormView, CFormView)

CTestSDIFormView::CTestSDIFormView()
	: CFormView(CTestSDIFormView::IDD)
{
	//{{AFX_DATA_INIT(CTestSDIFormView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CTestSDIFormView::~CTestSDIFormView()
{
}

void CTestSDIFormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestSDIFormView)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestSDIFormView, CFormView)
	//{{AFX_MSG_MAP(CTestSDIFormView)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSDIFormView diagnostics

#ifdef _DEBUG
void CTestSDIFormView::AssertValid() const
{
	CFormView::AssertValid();
}

void CTestSDIFormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestSDIFormView message handlers

void CTestSDIFormView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	
}

void CTestSDIFormView::OnButton1() 
{
	// TODO: Add your control notification handler code here
	MessageBox("�Ҿ���һ����ťû���κ�����!!!");
}
