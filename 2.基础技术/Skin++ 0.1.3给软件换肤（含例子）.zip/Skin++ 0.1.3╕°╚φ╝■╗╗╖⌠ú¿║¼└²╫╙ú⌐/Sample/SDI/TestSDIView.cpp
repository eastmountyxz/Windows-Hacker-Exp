// TestSDIView.cpp : implementation of the CTestSDIView class
//

#include "stdafx.h"
#include "TestSDI.h"

#include "TestSDIDoc.h"
#include "TestSDIView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSDIView

IMPLEMENT_DYNCREATE(CTestSDIView, CListView)

BEGIN_MESSAGE_MAP(CTestSDIView, CListView)
	//{{AFX_MSG_MAP(CTestSDIView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CListView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CListView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CListView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSDIView construction/destruction

CTestSDIView::CTestSDIView()
{
	// TODO: add construction code here
	m_Inited=FALSE;
}

CTestSDIView::~CTestSDIView()
{
}

BOOL CTestSDIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style|=LVS_REPORT;
	return CListView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestSDIView drawing

void CTestSDIView::OnDraw(CDC* pDC)
{
	CTestSDIDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CTestSDIView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();
	if(!m_Inited)
	{
		m_Inited=TRUE;
		CListCtrl * pCtrl=&this->GetListCtrl();
		pCtrl->InsertColumn(0,"����1",LVCFMT_LEFT,200);
		pCtrl->InsertColumn(1,"����2",LVCFMT_LEFT,100);

		pCtrl->InsertItem(0,"����LISTVIEW",-1);
		pCtrl->InsertItem(1,"�ҵ���ҳ��http://www.uipower.com",-1);

		CString ss;
		for(int i=2;i<20;i++)
		{
			ss.Format("�������� %d",i);
			pCtrl->InsertItem(i,ss,-1);
		}
	
	}

	// TODO: You may populate your ListView with items by directly accessing
	//  its list control through a call to GetListCtrl().
}

/////////////////////////////////////////////////////////////////////////////
// CTestSDIView printing

BOOL CTestSDIView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTestSDIView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTestSDIView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTestSDIView diagnostics

#ifdef _DEBUG
void CTestSDIView::AssertValid() const
{
	CListView::AssertValid();
}

void CTestSDIView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CTestSDIDoc* CTestSDIView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestSDIDoc)));
	return (CTestSDIDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestSDIView message handlers
