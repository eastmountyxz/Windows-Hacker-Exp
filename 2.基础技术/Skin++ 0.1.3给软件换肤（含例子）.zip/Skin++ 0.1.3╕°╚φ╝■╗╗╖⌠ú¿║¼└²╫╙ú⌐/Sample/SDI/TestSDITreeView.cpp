// TestSDITreeView.cpp : implementation file
//

#include "stdafx.h"
#include "TestSDI.h"
#include "TestSDITreeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSDITreeView

IMPLEMENT_DYNCREATE(CTestSDITreeView, CTreeView)

CTestSDITreeView::CTestSDITreeView()
{
	m_Inited=FALSE;
}

CTestSDITreeView::~CTestSDITreeView()
{
}


BEGIN_MESSAGE_MAP(CTestSDITreeView, CTreeView)
	//{{AFX_MSG_MAP(CTestSDITreeView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSDITreeView drawing

void CTestSDITreeView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CTestSDITreeView diagnostics

#ifdef _DEBUG
void CTestSDITreeView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTestSDITreeView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestSDITreeView message handlers

void CTestSDITreeView::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	if(!m_Inited)
	{
		m_Inited=TRUE;
		CTreeCtrl * pCtrl=&this->GetTreeCtrl();

		pCtrl->InsertItem("����TREEVIEW",-1,-1);
		pCtrl->InsertItem("������:UIPower",-1,-1);
		CString ss;
		for(int i=2;i<20;i++)
		{
			ss.Format("�������� %d",i);
			pCtrl->InsertItem(ss,-1,-1);
		}
	
	}	
}
