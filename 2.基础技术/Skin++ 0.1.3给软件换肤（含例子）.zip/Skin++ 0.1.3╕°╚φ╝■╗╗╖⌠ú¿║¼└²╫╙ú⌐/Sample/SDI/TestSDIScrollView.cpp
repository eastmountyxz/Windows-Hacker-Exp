// TestSDIScrollView.cpp : implementation file
//

#include "stdafx.h"
#include "TestSDI.h"
#include "TestSDIScrollView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSDIScrollView

IMPLEMENT_DYNCREATE(CTestSDIScrollView, CScrollView)

CTestSDIScrollView::CTestSDIScrollView()
{
}

CTestSDIScrollView::~CTestSDIScrollView()
{
}


BEGIN_MESSAGE_MAP(CTestSDIScrollView, CScrollView)
	//{{AFX_MSG_MAP(CTestSDIScrollView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSDIScrollView drawing

void CTestSDIScrollView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = sizeTotal.cy = 100;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

void CTestSDIScrollView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CTestSDIScrollView diagnostics

#ifdef _DEBUG
void CTestSDIScrollView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTestSDIScrollView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestSDIScrollView message handlers
