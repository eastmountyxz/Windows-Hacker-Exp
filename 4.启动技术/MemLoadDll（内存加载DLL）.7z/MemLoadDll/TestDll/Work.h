#pragma once
#include<string>
using namespace std;

VOID PrintfMse(const string &strMessage);