#include "stdafx.h"
#include "Work.h"
#include <Windows.h>

VOID PrintfMse(const string &strMessage){
	MessageBoxA(NULL ,strMessage.c_str() ,"tit" ,MB_OK);
	return ;
}