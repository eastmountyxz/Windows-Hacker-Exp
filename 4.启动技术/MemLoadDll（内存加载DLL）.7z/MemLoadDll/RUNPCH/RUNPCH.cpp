// RUNPCH.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <string>
#include <windows.h>
#include <shlwapi.h>
#include "module/zishiA/MemLoadDll.h"
#pragma comment(lib, "shlwapi.lib")
using namespace std;
#pragma warning(disable : 4996)

unsigned char bMemory[1024*1024*5] = {0};

DWORD dwLoadDll2Memory(string strDllPath){
	FILE *fpLoadDll; 
	char cCache[1024];            
	if((fpLoadDll = fopen(strDllPath.c_str(),"rb")) == NULL) { 
		return 0;
	} 
	DWORD dwNowReadId = 0;
	while (1) { 
		ZeroMemory(cCache ,sizeof(cCache));
		DWORD dwReadSize = fread(cCache,1,1024 ,fpLoadDll);
		DWORD dwErrorCode = GetLastError();
		if(dwReadSize == 0){
			break;
		}
		for(int i = 1 ;i <= dwReadSize ;i ++){
			bMemory[dwNowReadId++] = cCache[i-1];
		}
	} 
	fclose(fpLoadDll);     
	return dwNowReadId;
}

VOID SetCurrentDir(){
	WCHAR wcLocalPath[MAX_PATH*2] = {0};
	GetModuleFileName(0 ,wcLocalPath ,MAX_PATH);
	PathRemoveFileSpec(wcLocalPath);
	SetCurrentDirectory(wcLocalPath);
}


int _tmain(int argc, _TCHAR* argv[])
{
//mark : After loading a function related to the memory will be released, that is, only one function can be loaded to perform

	SetCurrentDir();

	DWORD dwFileLength = dwLoadDll2Memory("TestDll.dll");
	CMemLoadDll *clLoadClass = new CMemLoadDll();
	BOOL  bLoadDllResult  = clLoadClass->MemLoadLibrary(bMemory ,dwFileLength);	

	if(bLoadDllResult){
	    typedef VOID (*TYPEPRINTFMSE)(const string &strMessage);
	    TYPEPRINTFMSE _PrintfMse = (TYPEPRINTFMSE)clLoadClass->MemGetProcAddress("PrintfMse");
		if(_PrintfMse){
			_PrintfMse("Memory load function executed successfully!");
		}else{
			// getprocaddress error
		}
	}else{
		//loadlibrary error
	}

	delete clLoadClass;
	return 0;
}

